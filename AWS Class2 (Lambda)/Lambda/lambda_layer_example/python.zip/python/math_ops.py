def square(num):
    return num ** 2

def sum(num1, num2):
    return num1 + num2
    