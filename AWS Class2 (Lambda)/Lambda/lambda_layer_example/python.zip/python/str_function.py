def double_str(string):
    return string * 2